from flask import Flask, render_template, redirect, request, url_for, flash
import numpy as np
import pickle

app = Flask(__name__)
app.secret_key = '_5#y2L"F4Q8z\n\xec]/'

@app.route('/')
@app.route('/loginHDP')
def login():
    return render_template('loginHDP.html')

@app.route('/results')
def results(): 
    if request.method == 'GET':
        
        age = int(request.args['age'])
        sex = int(request.args['gender'])
        cp = int(request.args['cp'])
        trestbps = int(request.args['trestbps'])
        chol = int(request.args['chol'])
        fbs = int(request.args['fbs'])
        restecg = int(request.args['restecg'])
        thalach = int(request.args['thalach'])
        exang = int(request.args['exang'])
        oldpeak = float(request.args['oldpeak'])
        slope = int(request.args['slope'])
        ca = int(request.args['ca'])
        thal = int(request.args['thal'])

        sample = np.array([age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]).reshape(1, -1)
        
        testing_pickle = pickle.load(open("heart_model.pkl","rb"))

        prediction = testing_pickle.predict(sample)

        if prediction == 1:
            res = "shows symptoms of heart disease"
        else:
            res = "looks safe...!"

        return render_template('results.html',res = res)

if __name__ == '__main__':
    app.run(debug=True)    


